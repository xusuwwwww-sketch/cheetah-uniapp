<script>
export default {
  onLaunch() {},
  onShow() {},
  onHide() {}
}
</script>

<style>
page {
  min-height: 100%;
  background: #f5f5f7;
  color: #1a1a2e;
  font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Helvetica Neue", Arial, sans-serif;
}

view,
text,
scroll-view,
swiper,
swiper-item,
input,
textarea,
button {
  box-sizing: border-box;
}

button {
  margin: 0;
  padding: 0;
  line-height: normal;
  background: transparent;
  border-radius: 0;
}

button::after {
  border: 0;
}
</style>
