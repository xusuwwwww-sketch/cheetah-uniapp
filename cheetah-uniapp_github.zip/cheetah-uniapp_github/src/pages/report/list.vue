<template>
  <view class="page">
    <view class="top-header"><text class="page-title">行业报告</text></view>
    <scroll-view class="filter-bar" scroll-x :show-scrollbar="false">
      <view v-for="f in filters" :key="f.key" class="filter-btn" :class="{ active: activeFilter === f.key }" @tap="activeFilter = f.key">
        <text>{{ f.label }}</text>
      </view>
    </scroll-view>
    <scroll-view class="list-scroll" scroll-y :show-scrollbar="false">
      <view class="section">
        <view v-for="item in reports" :key="item.id" class="report-card" @tap="goDetail(item)">
          <view class="report-cover" :style="{ background: item.gradient }">
            <text class="report-watermark">REPORT</text>
            <text class="report-badge" :class="item.free ? 'free' : 'vip'">{{ item.free ? '免费' : '付费' }}</text>
          </view>
          <view class="report-body">
            <text class="report-title">{{ item.title }}</text>
            <view class="report-meta"><text>{{ item.date }}</text><text>{{ item.source }}</text></view>
          </view>
        </view>
      </view>
    </scroll-view>
  </view>
</template>
<script>
export default {
  data() {
    return {
      activeFilter: 'all',
      filters: [{ key: 'all', label: '全部' }, { key: 'sea', label: '东南亚' }, { key: 'me', label: '中东' }, { key: '2026', label: '2026' }],
      reports: [
        { id: 1, title: '2026年Q2中国出海品牌Top50排行榜', date: '2026-06-15', source: '猎豹研究院', free: true, gradient: 'linear-gradient(135deg, #1e3a5f, #2d5f8a)' },
        { id: 2, title: '东南亚社交媒体营销白皮书 2026', date: '2026-06-10', source: 'CheetahGo', free: false, gradient: 'linear-gradient(135deg, #2d1b4e, #5b3a8c)' },
        { id: 3, title: '中东市场游戏出海深度报告', date: '2026-06-08', source: '出海情报站', free: true, gradient: 'linear-gradient(135deg, #1a3c34, #2d6b5a)' },
        { id: 4, title: '拉美电商市场机遇与挑战全景分析', date: '2026-05-28', source: '猎豹研究院', free: false, gradient: 'linear-gradient(135deg, #4a1942, #8b4578)' }
      ]
    }
  },
  methods: {
    goDetail(item) { uni.navigateTo({ url: `/pages/report/detail?id=${item.id}` }) }
  }
}
</script>
<style scoped>
.page { background: #f6f7fb; min-height: 100vh; }
.top-header { height: 54px; padding: 12px 16px 8px; background: #fff; border-bottom: 0.5px solid #e5e7eb; display: flex; align-items: center; }
.page-title { font-size: 17px; font-weight: 700; color: #1a1a2e; }
.filter-bar { white-space: nowrap; padding: 8px 14px; }
.filter-btn { display: inline-flex; align-items: center; height: 29px; padding: 0 14px; margin-right: 8px; border: 0.5px solid #e5e7eb; border-radius: 7px; color: #64748b; background: #fff; font-size: 12px; }
.filter-btn.active { color: #ff6b35; border-color: rgba(255,107,53,.35); background: #fff0ea; }
.list-scroll { height: calc(100vh - 54px - 45px); }
.section { padding: 12px 14px 20px; }
.report-card { margin-bottom: 10px; border-radius: 8px; background: #fff; overflow: hidden; border: 0.5px solid #e5e7eb; box-shadow: 0 4px 13px rgba(15,23,42,.05); }
.report-cover { position: relative; height: 110px; display: flex; align-items: center; justify-content: center; }
.report-watermark { color: rgba(255,255,255,.34); font-size: 14px; font-weight: 700; }
.report-badge { position: absolute; top: 8px; right: 8px; padding: 2.5px 8px; border-radius: 4px; color: #fff; font-size: 10px; font-weight: 700; }
.report-badge.free { background: #10b981; }
.report-badge.vip { background: #ff6b35; }
.report-body { padding: 12px 13px 13px; }
.report-title { display: block; color: #1a1a2e; font-size: 14px; line-height: 20px; font-weight: 600; }
.report-meta { display: flex; gap: 8px; margin-top: 4px; color: #9ca3af; font-size: 11px; }
</style>
