<template>
  <view class="page">
    <view class="back-header">
      <button class="back-btn" @tap="goBack">‹</button>
      <text class="back-title">报告详情</text>
    </view>
    <scroll-view class="detail-scroll" scroll-y :show-scrollbar="false">
      <view class="detail-cover" style="background: linear-gradient(135deg, #1e3a5f, #2d5f8a);">
        <text style="color:rgba(255,255,255,.3);font-size:14px;font-weight:700;">REPORT</text>
      </view>
      <view class="info-block">
        <text class="detail-title">2026年Q2中国出海品牌Top50排行榜</text>
        <view class="tags"><text class="tag">2026-06-15</text><text class="tag">猎豹研究院</text></view>
      </view>
      <view class="content-block">
        <text class="content-title">报告摘要</text>
        <text class="content-p">本报告基于猎豹大数据平台监测的5000+中国出海品牌数据，从品牌知名度、用户口碑、市场份额、增长趋势四个维度评选出2026年Q2中国出海品牌Top50，涵盖电商、游戏、社交、工具、教育五大行业。</text>
      </view>
    </scroll-view>
    <view class="cta-bar">
      <button class="btn-primary" @tap="download">免费下载</button>
    </view>
  </view>
</template>
<script>
export default {
  onLoad(options) { /* TODO: 根据 id 获取报告详情 */ },
  methods: {
    goBack() { uni.navigateBack() },
    download() { uni.showToast({ title: '请先登录后下载', icon: 'none' }) }
  }
}
</script>
<style scoped>
.page { background: #f6f7fb; min-height: 100vh; }
.back-header { position: fixed; top: 0; left: 0; right: 0; z-index: 50; height: 54px; padding: 12px 14px 8px; background: rgba(255,255,255,.96); border-bottom: 0.5px solid #e5e7eb; display: flex; align-items: center; }
.back-btn { width: 26px; height: 26px; border-radius: 8px; background: #f8fafc; color: #1a1a2e; font-size: 28px; line-height: 24px; display: flex; align-items: center; justify-content: center; }
.back-title { position: absolute; left: 50%; transform: translateX(-50%); font-size: 16px; font-weight: 700; color: #1a1a2e; }
.detail-scroll { height: calc(100vh - 54px - 64px); margin-top: 54px; }
.detail-cover { height: 180px; display: flex; align-items: center; justify-content: center; }
.info-block { background: #fff; padding: 16px 14px; }
.detail-title { display: block; color: #1a1a2e; font-size: 20px; line-height: 26px; font-weight: 800; }
.tags { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 12px; }
.tag { padding: 4px 10px; border-radius: 5px; background: #f6f7fb; color: #64748b; font-size: 12px; }
.content-block { margin: 10px 14px; padding: 16px; border-radius: 8px; background: #fff; border: 0.5px solid #e5e7eb; }
.content-title { display: block; margin-bottom: 9px; color: #1a1a2e; font-size: 16px; font-weight: 800; }
.content-p { display: block; color: #6b7280; font-size: 14px; line-height: 24px; }
.cta-bar { position: fixed; bottom: 0; left: 0; right: 0; height: 64px; padding: 10px 14px; background: rgba(255,255,255,.96); border-top: 0.5px solid #e5e7eb; }
.btn-primary { width: 100%; height: 44px; border-radius: 8px; background: #ff6b35; color: #fff; font-size: 15px; font-weight: 800; display: flex; align-items: center; justify-content: center; }
</style>
