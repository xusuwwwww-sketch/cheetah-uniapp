<template>
  <view class="page">
    <view class="back-header">
      <button class="back-btn" @tap="goBack">‹</button>
      <text class="back-title">活动详情</text>
    </view>
    <scroll-view class="detail-scroll" scroll-y :show-scrollbar="false">
      <view class="detail-cover" :style="{ background: activity.gradient }">
        <view class="cover-center">
          <text class="cover-icon">{{ activity.icon }}</text>
          <text class="cover-title">{{ activity.title }}</text>
        </view>
      </view>
      <view class="info-block">
        <text class="detail-title">{{ activity.title }}</text>
        <view class="tags">
          <text class="tag">{{ activity.time }}</text>
          <text class="tag">{{ activity.location }}</text>
          <text class="tag">{{ activity.count }}</text>
        </view>
      </view>
      <view class="content-block">
        <text class="content-title">活动介绍</text>
        <text class="content-p">邀请行业资深从业者深度分享，覆盖市场趋势、实操策略和投放技巧，无论新手还是老手都能获得实际干货。</text>
        <text class="content-title">适合人群</text>
        <text class="content-p">跨境电商卖家、独立站运营、品牌出海负责人、广告投放专家。</text>
      </view>
    </scroll-view>
    <view class="cta-bar">
      <button class="btn-primary" @tap="signUp">{{ activity.full ? '已满额' : '立即报名' }}</button>
      <button class="btn-soft" @tap="share">分享</button>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      activity: {
        id: 1, title: '出海直播季·第12期', time: '6月28日 20:00',
        location: '线上直播', count: '已报 186', icon: 'LIVE',
        gradient: 'linear-gradient(135deg, #ff6b35, #ff9a5c)', full: false
      }
    }
  },
  onLoad(options) {
    // TODO: 根据 options.id 从接口获取活动详情
  },
  methods: {
    goBack() { uni.navigateBack() },
    signUp() {
      if (this.activity.full) { uni.showToast({ title: '该活动已满额', icon: 'none' }); return }
      uni.showToast({ title: '报名成功！', icon: 'success' })
    },
    share() { uni.showToast({ title: '分享功能建设中', icon: 'none' }) }
  }
}
</script>

<style scoped>
.page { background: #f6f7fb; min-height: 100vh; }
.back-header { position: fixed; top: 0; left: 0; right: 0; z-index: 50; height: 54px; padding: 12px 14px 8px; background: rgba(255,255,255,.96); border-bottom: 0.5px solid #e5e7eb; display: flex; align-items: center; }
.back-btn { width: 26px; height: 26px; border-radius: 8px; background: #f8fafc; color: #1a1a2e; font-size: 28px; line-height: 24px; display: flex; align-items: center; justify-content: center; }
.back-title { position: absolute; left: 50%; transform: translateX(-50%); font-size: 16px; font-weight: 700; color: #1a1a2e; }
.detail-scroll { height: calc(100vh - 54px - 64px); margin-top: 54px; }
.detail-cover { height: 200px; display: flex; align-items: center; justify-content: center; }
.cover-center { display: flex; flex-direction: column; align-items: center; gap: 8px; color: #fff; }
.cover-icon { font-size: 28px; font-weight: 800; }
.cover-title { font-size: 16px; font-weight: 700; text-align: center; padding: 0 20px; }
.info-block { background: #fff; padding: 16px 14px; }
.detail-title { display: block; color: #1a1a2e; font-size: 20px; line-height: 26px; font-weight: 800; }
.tags { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 12px; }
.tag { padding: 4px 10px; border-radius: 5px; background: #f6f7fb; color: #64748b; font-size: 12px; }
.content-block { margin: 10px 14px; padding: 16px; border-radius: 8px; background: #fff; border: 0.5px solid #e5e7eb; }
.content-title { display: block; margin-bottom: 9px; color: #1a1a2e; font-size: 16px; font-weight: 800; }
.content-p { display: block; margin-bottom: 14px; color: #6b7280; font-size: 14px; line-height: 24px; }
.cta-bar { position: fixed; bottom: 0; left: 0; right: 0; height: 64px; padding: 10px 14px; background: rgba(255,255,255,.96); border-top: 0.5px solid #e5e7eb; display: flex; gap: 10px; }
.btn-primary { flex: 1; height: 44px; border-radius: 8px; background: #ff6b35; color: #fff; font-size: 15px; font-weight: 800; display: flex; align-items: center; justify-content: center; }
.btn-soft { width: 90px; height: 44px; border-radius: 8px; background: #fff0ea; color: #ff6b35; font-size: 14px; font-weight: 700; display: flex; align-items: center; justify-content: center; }
</style>
