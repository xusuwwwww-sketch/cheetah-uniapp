<template>
  <view class="page">
    <!-- 顶部导航 -->
    <view class="top-header">
      <text class="page-title">活动</text>
    </view>

    <!-- Tab -->
    <scroll-view class="sub-tabs" scroll-x :show-scrollbar="false">
      <view
        v-for="tab in tabs"
        :key="tab.key"
        class="sub-tab"
        :class="{ active: activeTab === tab.key }"
        @tap="activeTab = tab.key"
      >
        <text>{{ tab.label }}</text>
      </view>
    </scroll-view>

    <!-- 搜索 -->
    <view class="search-bar">
      <text class="search-icon">🔍</text>
      <input class="search-input" v-model="keyword" placeholder="搜索活动名称、关键词..." placeholder-class="placeholder" />
    </view>

    <!-- 活动列表 -->
    <scroll-view class="list-scroll" scroll-y :show-scrollbar="false">
      <view class="section">
        <view
          v-for="item in filteredActivities"
          :key="item.id"
          class="activity-card"
          @tap="goDetail(item)"
        >
          <view class="activity-cover" :style="{ background: item.gradient }">
            <text class="activity-glyph">{{ item.icon }}</text>
          </view>
          <view class="activity-body">
            <text class="activity-title">{{ item.title }}</text>
            <view class="activity-info">
              <text>{{ item.time }}</text>
              <text>{{ item.location }}</text>
              <text>{{ item.count }}</text>
            </view>
            <button
              class="mini-primary"
              :class="{ outline: item.full }"
              @tap.stop="signUp(item)"
            >
              {{ item.full ? '已满额' : '立即报名' }}
            </button>
          </view>
        </view>
        <view v-if="filteredActivities.length === 0" class="empty">
          <text>暂无相关活动</text>
        </view>
      </view>
    </scroll-view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      activeTab: 'live',
      keyword: '',
      tabs: [
        { key: 'live', label: '直播' },
        { key: 'closed', label: '闭门会' },
        { key: 'salon', label: '线下沙龙' },
        { key: 'camp', label: '专题训练营' }
      ],
      activities: [
        { id: 1, type: 'live', title: '出海直播季·第12期：TikTok Shop 新加坡爆单秘籍', time: '6月28日 20:00', location: '线上直播', count: '已报 186', icon: 'LIVE', gradient: 'linear-gradient(135deg, #ff6b35, #ff9a5c)' },
        { id: 2, type: 'live', title: 'AI 时代的买量投放策略：从手动到智能', time: '7月5日 19:30', location: '线上直播', count: '已报 92', icon: 'AI', gradient: 'linear-gradient(135deg, #2563eb, #60a5fa)' },
        { id: 3, type: 'live', title: '出海实战：独立站从0到100万美元的完整路径', time: '7月12日 20:00', location: '线上直播', count: '已报 245', icon: 'SHOP', full: true, gradient: 'linear-gradient(135deg, #10b981, #34d399)' },
        { id: 4, type: 'closed', title: '中东品牌增长闭门会：支付、合规与渠道打法', time: '7月18日 14:00', location: '深圳南山', count: '已报 38', icon: 'VIP', gradient: 'linear-gradient(135deg, #1a1a2e, #3f3f5a)' },
        { id: 5, type: 'salon', title: '独立站运营沙龙：从素材测试到转化漏斗优化', time: '7月24日 15:00', location: '上海静安', count: '已报 64', icon: '沙龙', gradient: 'linear-gradient(135deg, #f59e0b, #fbbf24)' },
        { id: 6, type: 'camp', title: '跨境广告投放7天训练营', time: '8月1日开营', location: '线上训练营', count: '已报 112', icon: '营', gradient: 'linear-gradient(135deg, #8b5cf6, #a78bfa)' }
      ]
    }
  },
  computed: {
    filteredActivities() {
      return this.activities.filter(item => {
        const matchTab = item.type === this.activeTab
        const matchKeyword = !this.keyword || item.title.includes(this.keyword)
        return matchTab && matchKeyword
      })
    }
  },
  methods: {
    goDetail(item) {
      uni.navigateTo({ url: `/pages/activity/detail?id=${item.id}` })
    },
    signUp(item) {
      if (item.full) {
        uni.showToast({ title: '该活动已满额', icon: 'none' })
        return
      }
      uni.navigateTo({ url: `/pages/activity/detail?id=${item.id}` })
    }
  }
}
</script>

<style scoped>
.page { background: #f6f7fb; min-height: 100vh; }
.top-header { height: 54px; padding: 12px 16px 8px; background: #fff; border-bottom: 0.5px solid #e5e7eb; display: flex; align-items: center; }
.page-title { font-size: 17px; font-weight: 700; color: #1a1a2e; }
.sub-tabs { width: 100%; white-space: nowrap; padding: 8px 14px; background: #f6f7fb; }
.sub-tab { display: inline-flex; align-items: center; height: 29px; padding: 0 16px; margin-right: 6px; border-radius: 7px; background: #fff; color: #64748b; font-size: 13px; font-weight: 600; border: 0.5px solid #e5e7eb; }
.sub-tab.active { background: #ff6b35; color: #fff; border-color: #ff6b35; }
.search-bar { margin: 8px 14px 12px; height: 41px; padding: 0 12px; border-radius: 8px; background: #fff; border: 0.5px solid #e5e7eb; display: flex; align-items: center; gap: 8px; }
.search-icon { font-size: 14px; }
.search-input { flex: 1; height: 40px; font-size: 14px; color: #1a1a2e; }
.placeholder { color: #9ca3af; }
.list-scroll { height: calc(100vh - 54px - 45px - 61px); }
.section { padding: 0 14px 20px; }
.activity-card { margin-bottom: 10px; border-radius: 8px; background: #fff; overflow: hidden; border: 0.5px solid #e5e7eb; box-shadow: 0 4px 13px rgba(15,23,42,.05); }
.activity-cover { height: 110px; display: flex; align-items: center; justify-content: center; }
.activity-glyph { font-size: 22px; font-weight: 800; color: #fff; }
.activity-body { padding: 12px 13px 13px; }
.activity-title { display: block; color: #1a1a2e; font-size: 14px; line-height: 20px; font-weight: 600; }
.activity-info { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 4px; color: #9ca3af; font-size: 11px; }
.mini-primary { display: inline-flex; align-items: center; justify-content: center; min-width: 80px; height: 30px; margin-top: 10px; padding: 0 18px; border-radius: 499.5px; background: #ff6b35; color: #fff; font-size: 13px; font-weight: 700; }
.mini-primary.outline { background: transparent; border: 1.5px solid #ff6b35; color: #ff6b35; }
.empty { padding: 40px 0; text-align: center; color: #9ca3af; font-size: 14px; }
</style>
