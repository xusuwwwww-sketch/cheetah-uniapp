<template>
  <view class="page">
    <view class="top-header">
      <text class="page-title">约咨询</text>
    </view>
    <view class="coming-soon">
      <text class="coming-icon">🚧</text>
      <text class="coming-text">约咨询 功能建设中</text>
      <text class="coming-desc">敬请期待</text>
    </view>
  </view>
</template>
<script>
export default {}
</script>
<style scoped>
.page { background: #f6f7fb; min-height: 100vh; }
.top-header { height: 54px; padding: 12px 16px 8px; background: #fff; border-bottom: 0.5px solid #e5e7eb; display: flex; align-items: center; }
.page-title { font-size: 17px; font-weight: 700; color: #1a1a2e; }
.coming-soon { display: flex; flex-direction: column; align-items: center; justify-content: center; padding-top: 120px; gap: 12px; }
.coming-icon { font-size: 48px; }
.coming-text { font-size: 18px; font-weight: 700; color: #1a1a2e; }
.coming-desc { font-size: 14px; color: #9ca3af; }
</style>
