<template>
  <view class="toolbox-page">
    <view class="top-header">
      <view class="brand">
        <view class="logo-mark">
          <image class="logo-image" src="/static/icons-png/logo.png" mode="aspectFit" />
        </view>
        <text class="brand-name">猎豹出海工具箱</text>
      </view>
      <button class="header-action" @tap="toast('暂无新通知')">
        <image class="icon-image header-action-icon" src="/static/icons-png/bell-darkgray.png" mode="aspectFit" />
      </button>
    </view>

    <view class="main-scroll">
      <view v-show="activeTab === 'home'" class="page-panel">
        <view class="carousel-wrap">
          <swiper
            class="banner-swiper"
            circular
            :autoplay="true"
            :interval="3500"
            :duration="420"
            @change="handleBannerChange"
          >
            <swiper-item v-for="item in banners" :key="item.title">
              <view class="carousel-card" :style="{ background: item.gradient }">
                <view>
                  <text class="banner-tag">{{ item.tag }}</text>
                  <text class="banner-title">{{ item.title }}</text>
                  <text class="banner-desc">{{ item.desc }}</text>
                </view>
              </view>
            </swiper-item>
          </swiper>
          <view class="carousel-dots">
            <view
              v-for="(_, index) in banners"
              :key="index"
              class="dot"
              :class="{ active: bannerIndex === index }"
            />
          </view>
        </view>

        <view class="section">
          <view class="entry-grid">
            <view
              v-for="item in quickEntries"
              :key="item.label"
              class="entry-item"
              @tap="openSub(item.target)"
            >
              <view class="entry-icon" :style="{ background: item.gradient }">
                <image class="icon-image entry-glyph" :src="item.icon" mode="aspectFit" />
              </view>
              <text class="entry-label">{{ item.label }}</text>
            </view>
          </view>
        </view>

        <view class="section">
          <view class="section-title-row">
            <text class="section-title">热门社群</text>
            <text class="section-more">查看全部 ></text>
          </view>
          <scroll-view class="community-scroll" scroll-x :show-scrollbar="false">
            <view
              v-for="item in communities"
              :key="item.title"
              class="community-card"
            >
              <view class="cc-icon" :style="{ background: item.bg }">
                <image class="icon-image cc-glyph" :src="item.icon" mode="aspectFit" />
              </view>
              <text class="card-title">{{ item.title }}</text>
              <text class="card-desc">{{ item.desc }}</text>
            </view>
          </scroll-view>
        </view>

        <view class="section last-section">
          <view class="section-title-row">
            <text class="section-title">精选报告</text>
            <text class="section-more" @tap="openSub('reports')">更多 ></text>
          </view>
          <view
            v-for="item in featuredReports"
            :key="item.title"
            class="report-card"
            @tap="openSub('reportDetail')"
          >
            <view class="report-cover" :style="{ background: item.gradient }">
              <text class="report-watermark">REPORT</text>
              <text class="report-badge" :class="item.badge === '免费' ? 'free' : 'vip'">{{ item.badge }}</text>
            </view>
            <view class="report-body">
              <text class="report-title">{{ item.title }}</text>
              <view class="report-meta">
                <text>{{ item.date }}</text>
                <text>{{ item.source }}</text>
              </view>
            </view>
          </view>
        </view>
      </view>

      <view v-show="activeTab === 'activities'" class="page-panel">
        <view class="page-heading">
          <text>活动</text>
        </view>
        <scroll-view class="sub-tabs" scroll-x :show-scrollbar="false">
          <view
            v-for="tab in activityTabs"
            :key="tab.key"
            class="sub-tab"
            :class="{ active: activeActivityTab === tab.key }"
            @tap="activeActivityTab = tab.key"
          >
            <text>{{ tab.label }}</text>
          </view>
        </scroll-view>
        <view class="search-bar">
          <image class="icon-image search-icon" src="/static/icons-png/search-gray.png" mode="aspectFit" />
          <input class="search-input" placeholder="搜索活动名称、关键词..." placeholder-class="placeholder" />
        </view>
        <view class="section">
          <view
            v-for="item in visibleActivities"
            :key="item.title"
            class="activity-card"
            @tap="openSub('activityDetail')"
          >
            <view class="activity-cover" :style="{ background: item.gradient }">
              <text class="activity-glyph">{{ item.icon }}</text>
            </view>
            <view class="activity-body">
              <text class="activity-title">{{ item.title }}</text>
              <view class="activity-info">
                <text>{{ item.time }}</text>
                <text>{{ item.location }}</text>
                <text>{{ item.count }}</text>
              </view>
              <button
                class="mini-primary"
                :class="{ outline: item.full }"
                @tap.stop="signActivity(item)"
              >
                {{ item.full ? '已满额' : '立即报名' }}
              </button>
            </view>
          </view>
        </view>
      </view>

      <view v-show="activeTab === 'services'" class="page-panel">
        <view class="page-heading">
          <text>服务</text>
        </view>
        <view v-for="group in serviceGroups" :key="group.title" class="service-group">
          <text class="service-group-title">{{ group.title }}</text>
          <view class="service-list">
            <view
              v-for="item in group.items"
              :key="item.title"
              class="service-item"
              @tap="item.target ? openSub(item.target) : toast('功能建设中')"
            >
              <view class="service-icon" :style="{ background: item.gradient }">
                <image class="icon-image service-glyph" :src="item.icon" mode="aspectFit" />
              </view>
              <view class="service-copy">
                <text class="service-title">{{ item.title }}</text>
                <text class="service-desc">{{ item.desc }}</text>
              </view>
              <text class="chevron">›</text>
            </view>
          </view>
        </view>
      </view>

      <view v-show="activeTab === 'profile'" class="page-panel">
        <view class="profile-card">
          <view class="profile-avatar">
            <text>我</text>
          </view>
          <view>
            <text class="profile-name">出海从业者</text>
            <text class="profile-desc">点击登录，解锁更多权益</text>
          </view>
        </view>

        <view class="menu-list">
          <view class="menu-item" @tap="showModal('loginModal')">
            <image class="icon-image menu-icon" src="/static/icons-png/user-wechat.png" mode="aspectFit" />
            <text class="menu-text">微信登录</text>
            <text class="chevron">›</text>
          </view>
        </view>
        <view class="menu-list">
          <view v-for="item in profileMenus" :key="item.label" class="menu-item" @tap="toast('请先登录')">
            <image class="icon-image menu-icon" :src="item.icon" mode="aspectFit" />
            <text class="menu-text">{{ item.label }}</text>
            <text class="chevron">›</text>
          </view>
        </view>
        <view class="menu-list">
          <view class="menu-item" @tap="toast('设置功能建设中')">
            <image class="icon-image menu-icon" src="/static/icons-png/grid-gray.png" mode="aspectFit" />
            <text class="menu-text">系统设置</text>
            <text class="chevron">›</text>
          </view>
        </view>
      </view>
    </view>

    <view class="bottom-tabs">
      <view
        v-for="item in tabs"
        :key="item.key"
        class="bottom-tab"
        :class="{ active: activeTab === item.key }"
        @tap="switchTab(item.key)"
      >
        <image class="icon-image bottom-icon" :src="activeTab === item.key ? item.activeIcon : item.icon" mode="aspectFit" />
        <text class="bottom-label">{{ item.label }}</text>
      </view>
    </view>

    <view v-if="activeSub" class="sub-page show">
      <view class="back-header">
        <button class="back-button" @tap="closeSub">‹</button>
        <text class="back-title">{{ subTitle }}</text>
      </view>
      <scroll-view
        class="sub-scroll"
        :class="{ 'with-cta': activeSub === 'activityDetail' || activeSub === 'reportDetail' }"
        scroll-y
        :show-scrollbar="false"
      >
        <view v-if="activeSub === 'activityDetail'">
          <view class="detail-cover" style="background: linear-gradient(135deg, #ff6b35, #ff9a5c);">
            <view class="detail-cover-center">
              <text class="detail-cover-icon">LIVE</text>
              <text class="detail-cover-title">出海直播季</text>
            </view>
          </view>
          <view class="detail-info-block">
            <text class="detail-title">出海直播季·第12期：TikTok Shop 新加坡爆单秘籍</text>
            <view class="detail-tags">
              <text class="detail-tag">2026年6月28日 20:00</text>
              <text class="detail-tag">线上直播</text>
              <text class="detail-tag">猎豹出海</text>
              <text class="detail-tag">限额500人</text>
            </view>
          </view>
          <view class="detail-content">
            <text class="detail-content-title">活动介绍</text>
            <text class="detail-p">邀请 TikTok Shop 新加坡区域负责人及3位GMV破百万卖家，深度拆解新加坡电商市场趋势、选品逻辑、达人合作策略和投放技巧。</text>
            <text class="detail-p">无论你是刚入局的新手还是寻求突破的老卖家，这场直播都能给你带来实实在在的干货。</text>
            <text class="detail-content-title">嘉宾阵容</text>
            <text class="detail-p">TikTok Shop 新加坡区域负责人、GMV月入百万卖家、猎豹出海高级投放专家。</text>
            <text class="detail-content-title">适合人群</text>
            <text class="detail-p">跨境电商卖家、独立站运营、品牌出海负责人、TikTok 内容创作者。</text>
          </view>
        </view>

        <view v-if="activeSub === 'reports'">
          <scroll-view class="filter-bar" scroll-x :show-scrollbar="false">
            <view
              v-for="filter in reportFilters"
              :key="filter.key"
              class="filter-btn"
              :class="{ active: activeFilters.reports.includes(filter.key) }"
              @tap="toggleFilter('reports', filter.key)"
            >
              <text>{{ filter.label }}</text>
            </view>
          </scroll-view>
          <view class="section top-gap">
            <view
              v-for="item in reports"
              :key="item.title"
              class="report-card"
              @tap="openSub('reportDetail')"
            >
              <view class="report-cover" :style="{ background: item.gradient }">
                <text class="report-watermark">REPORT</text>
                <text class="report-badge" :class="item.badge === '免费' ? 'free' : 'vip'">{{ item.badge }}</text>
              </view>
              <view class="report-body">
                <text class="report-title">{{ item.title }}</text>
                <view class="report-meta">
                  <text>{{ item.date }}</text>
                  <text>{{ item.source }}</text>
                </view>
              </view>
            </view>
          </view>
        </view>

        <view v-if="activeSub === 'cases'">
          <view class="search-bar">
            <image class="icon-image search-icon" src="/static/icons-png/search-gray.png" mode="aspectFit" />
            <input class="search-input" placeholder="搜索案例..." placeholder-class="placeholder" />
          </view>
          <scroll-view class="filter-bar" scroll-x :show-scrollbar="false">
            <view
              v-for="filter in caseFilters"
              :key="filter.key"
              class="filter-btn"
              :class="{ active: activeFilters.cases.includes(filter.key) }"
              @tap="toggleFilter('cases', filter.key)"
            >
              <text>{{ filter.label }}</text>
            </view>
          </scroll-view>
          <view class="section">
            <view v-for="item in cases" :key="item.title" class="activity-card">
              <view class="activity-cover" :style="{ background: item.gradient }">
                <text class="activity-glyph">{{ item.icon }}</text>
              </view>
              <view class="activity-body">
                <text class="activity-title">{{ item.title }}</text>
                <view class="activity-info">
                  <text>{{ item.industry }}</text>
                  <text>{{ item.service }}</text>
                </view>
                <view class="metric-row">
                  <text v-for="metric in item.metrics" :key="metric" class="metric-badge">{{ metric }}</text>
                </view>
              </view>
            </view>
          </view>
        </view>

        <view v-if="activeSub === 'materials'">
          <view class="material-tabs">
            <view
              v-for="tab in materialTabs"
              :key="tab.key"
              class="material-tab"
              :class="{ active: activeMaterialTab === tab.key }"
              @tap="setMaterialTab(tab.key)"
            >
              <text>{{ tab.label }}</text>
            </view>
          </view>
          <view class="section top-gap">
            <view v-for="item in materialFiles" :key="item.title" class="report-card">
              <view class="material-cover" :style="{ background: item.gradient }">
                <text>PDF</text>
              </view>
              <view class="report-body">
                <text class="report-title">{{ item.title }}</text>
                <view class="report-meta">
                  <text>{{ item.size }}</text>
                  <text>{{ item.date }}</text>
                </view>
              </view>
            </view>
          </view>
        </view>

        <view v-if="activeSub === 'consult'">
          <view class="consult-hero">
            <text class="consult-title">1对1 专家咨询</text>
            <text class="consult-desc">猎豹出海资深顾问，为您量身定制出海方案</text>
          </view>
          <view class="consult-highlights">
            <view v-for="item in consultHighlights" :key="item" class="consult-hl-item">
              <image class="icon-image consult-hl-icon" src="/static/icons-png/check-orange.png" mode="aspectFit" />
              <text>{{ item }}</text>
            </view>
          </view>
          <view class="form-section">
            <text class="form-title">预约咨询</text>
            <view class="form-group">
              <text class="form-label">您的姓名</text>
              <input class="form-input" placeholder="请输入您的姓名" placeholder-class="placeholder" />
            </view>
            <view class="form-group">
              <text class="form-label">联系电话</text>
              <input class="form-input" placeholder="请输入手机号码" placeholder-class="placeholder" />
            </view>
            <view class="form-group">
              <text class="form-label">公司名称</text>
              <input class="form-input" placeholder="请输入公司名称" placeholder-class="placeholder" />
            </view>
            <view class="form-group">
              <text class="form-label">咨询主题</text>
              <picker :range="consultTopics" @change="handlePicker('consultTopic', consultTopics, $event)">
                <view class="form-input select-input">
                  <text :class="{ muted: !consultTopic }">{{ consultTopic || '请选择咨询方向' }}</text>
                  <text>⌄</text>
                </view>
              </picker>
            </view>
            <view class="form-group">
              <text class="form-label">补充说明（选填）</text>
              <textarea class="form-input form-textarea" placeholder="简要描述您的需求或问题" placeholder-class="placeholder" />
            </view>
            <button class="btn-primary" @tap="showModal('deepFormModal')">提交预约</button>
          </view>
          <view class="community-join">
            <view class="join-icon">微</view>
            <view class="join-copy">
              <text class="join-title">加入出海交流社群</text>
              <text class="join-desc">与1,280+出海同行交流经验</text>
            </view>
            <text class="chevron">›</text>
          </view>
        </view>

        <view v-if="activeSub === 'reportDetail'">
          <view class="detail-cover" style="background: linear-gradient(135deg, #1e3a5f, #2d5f8a);">
            <text class="report-cover-text">报告封面</text>
          </view>
          <view class="detail-info-block">
            <text class="detail-title">2026年Q2中国出海品牌Top50排行榜</text>
            <view class="detail-tags">
              <text class="detail-tag">2026-06-15</text>
              <text class="detail-tag">猎豹研究院</text>
            </view>
          </view>
          <view class="detail-content">
            <text class="detail-content-title">报告摘要</text>
            <text class="detail-p">本报告基于猎豹大数据平台监测的5000+中国出海品牌数据，从品牌知名度、用户口碑、市场份额、增长趋势四个维度评选出2026年Q2中国出海品牌Top50。</text>
            <text class="detail-p">涵盖电商、游戏、社交、工具、教育五大行业，覆盖东南亚、中东、拉美、非洲等新兴市场。</text>
          </view>
        </view>
      </scroll-view>

      <view v-if="activeSub === 'activityDetail'" class="detail-cta-bar">
        <button class="btn-cta primary" @tap="showModal('infoModal')">立即报名</button>
        <button class="btn-cta soft" @tap="toast('分享卡片已准备')">
          <image class="icon-image cta-icon" src="/static/icons-png/share-orange.png" mode="aspectFit" />
          <text>分享</text>
        </button>
      </view>
      <view v-if="activeSub === 'reportDetail'" class="detail-cta-bar">
        <button class="btn-cta primary" @tap="showModal('infoModal')">
          <image class="icon-image cta-icon light" src="/static/icons-png/download-white.png" mode="aspectFit" />
          <text>免费下载</text>
        </button>
      </view>
    </view>

    <view v-if="activeModal" class="modal-overlay" @tap="hideModal(activeModal)">
      <view
        v-if="activeModal === 'loginModal'"
        class="modal login-modal"
        @tap.stop
      >
        <button class="modal-close" @tap="hideModal('loginModal')">×</button>
        <view class="login-logo">
          <image class="logo-image" src="/static/icons-png/logo.png" mode="aspectFit" />
        </view>
        <text class="modal-title">猎豹出海工具箱</text>
        <text class="modal-desc">申请获取以下权限以完成登录</text>
        <view class="permission-list">
          <text class="permission-item">✓ 获取你的昵称、头像</text>
          <text class="permission-item">✓ 获取你的手机号</text>
        </view>
        <button class="wx-btn" @tap="fromLoginToInfo">微信一键登录</button>
      </view>

      <view v-if="activeModal === 'infoModal'" class="modal form-modal" @tap.stop>
        <button class="modal-close orange" @tap="hideModal('infoModal')">×</button>
        <text class="modal-title left">完善基本信息</text>
        <text class="modal-desc left">帮助我们为您提供更精准的服务</text>
        <view class="form-group modal-field">
          <text class="form-label">姓名</text>
          <input class="form-input" placeholder="请输入您的姓名" placeholder-class="placeholder" />
        </view>
        <view class="form-group modal-field">
          <text class="form-label">所属行业</text>
          <picker :range="industries" @change="handlePicker('basicIndustry', industries, $event)">
            <view class="form-input select-input">
              <text :class="{ muted: !basicIndustry }">{{ basicIndustry || '请选择行业' }}</text>
              <text>⌄</text>
            </view>
          </picker>
        </view>
        <view class="form-group modal-field">
          <text class="form-label">职位</text>
          <input class="form-input" placeholder="请输入您的职位" placeholder-class="placeholder" />
        </view>
        <view class="form-group modal-field">
          <text class="form-label">邮箱</text>
          <input class="form-input" placeholder="请输入工作邮箱" placeholder-class="placeholder" />
        </view>
        <button class="btn-primary modal-submit" @tap="fromInfoToDeep">下一步</button>
      </view>

      <view v-if="activeModal === 'deepFormModal'" class="modal form-modal" @tap.stop>
        <button class="modal-close orange" @tap="hideModal('deepFormModal')">×</button>
        <text class="modal-title left">深度需求调研</text>
        <text class="modal-desc left">让我们更了解您的出海需求</text>
        <view class="form-group modal-field">
          <text class="form-label">公司名称</text>
          <input class="form-input" placeholder="请输入公司全称" placeholder-class="placeholder" />
        </view>
        <view class="form-group modal-field">
          <text class="form-label">月推广预算</text>
          <picker :range="budgets" @change="handlePicker('budget', budgets, $event)">
            <view class="form-input select-input">
              <text :class="{ muted: !budget }">{{ budget || '请选择预算范围' }}</text>
              <text>⌄</text>
            </view>
          </picker>
        </view>
        <view class="form-group modal-field">
          <text class="form-label">核心需求</text>
          <input class="form-input" placeholder="如：拓展东南亚市场" placeholder-class="placeholder" />
        </view>
        <view class="form-group modal-field">
          <text class="form-label">最大痛点</text>
          <textarea class="form-input form-textarea" placeholder="描述您在出海过程中遇到的最大挑战" placeholder-class="placeholder" />
        </view>
        <button class="btn-primary modal-submit" @tap="submitDeepForm">提交</button>
      </view>

      <view v-if="activeModal === 'successModal'" class="modal success-modal" @tap.stop>
        <view class="success-icon">✓</view>
        <text class="success-title">提交成功</text>
        <text class="success-desc">我们将在1个工作日内与您联系，感谢您的信任！</text>
        <button class="btn-primary" @tap="hideModal('successModal')">我知道了</button>
      </view>

      <view v-if="activeModal === 'posterModal'" class="modal poster-modal" @tap.stop>
        <button class="poster-close" @tap="hideModal('posterModal')">×</button>
        <swiper
          class="poster-swiper"
          circular
          :autoplay="true"
          :interval="3000"
          :duration="380"
          @change="handlePosterChange"
        >
          <swiper-item v-for="item in posters" :key="item.title">
            <view class="poster-slide" :style="{ background: item.gradient }">
              <text class="poster-title">{{ item.title }}</text>
              <text class="poster-desc">{{ item.desc }}</text>
              <button class="poster-cta" @tap="hideModal('posterModal')">{{ item.action }}</button>
            </view>
          </swiper-item>
        </swiper>
        <view class="poster-dots">
          <view
            v-for="(_, index) in posters"
            :key="index"
            class="dot"
            :class="{ active: posterIndex === index }"
          />
        </view>
      </view>
    </view>
  </view>
</template>

<script>
import homeGray from '../../../static/icons-png/home-gray.png'
import homeOrange from '../../../static/icons-png/home-orange.png'
import calendarGray from '../../../static/icons-png/calendar-gray.png'
import calendarOrange from '../../../static/icons-png/calendar-orange.png'
import gridGray from '../../../static/icons-png/grid-gray.png'
import gridOrange from '../../../static/icons-png/grid-orange.png'
import userGray from '../../../static/icons-png/user-gray.png'
import userOrange from '../../../static/icons-png/user-orange.png'
import eventWhite from '../../../static/icons-png/event-white.png'
import reportWhite from '../../../static/icons-png/report-white.png'
import caseWhite from '../../../static/icons-png/case-white.png'
import folderWhite from '../../../static/icons-png/folder-white.png'
import consultWhite from '../../../static/icons-png/consult-white.png'
import reportBlue from '../../../static/icons-png/report-blue.png'
import folderGreen from '../../../static/icons-png/folder-green.png'
import casePurple from '../../../static/icons-png/case-purple.png'
import checkAmber from '../../../static/icons-png/check-amber.png'
import searchWhite from '../../../static/icons-png/search-white.png'
import checkWhite from '../../../static/icons-png/check-white.png'
import folderOrange from '../../../static/icons-png/folder-orange.png'
import checkOrange from '../../../static/icons-png/check-orange.png'
import consultOrange from '../../../static/icons-png/consult-orange.png'

export default {
  data() {
    return {
      activeTab: 'home',
      activeSub: '',
      activeModal: '',
      bannerIndex: 0,
      posterIndex: 0,
      posterOpenTimer: null,
      activeActivityTab: 'live',
      activeMaterialTab: 'media',
      activeFilters: {
        reports: ['region'],
        cases: ['industry']
      },
      consultTopic: '',
      basicIndustry: '',
      budget: '',
      tabs: [
        { key: 'home', label: '首页', icon: homeGray, activeIcon: homeOrange },
        { key: 'activities', label: '活动', icon: calendarGray, activeIcon: calendarOrange },
        { key: 'services', label: '服务', icon: gridGray, activeIcon: gridOrange },
        { key: 'profile', label: '我的', icon: userGray, activeIcon: userOrange }
      ],
      banners: [
        {
          tag: '热门活动',
          title: '2026 出海增长峰会',
          desc: '7月15日 · 深圳南山 · 限额200人',
          gradient: 'linear-gradient(135deg, #ff6b35 0%, #ff9a5c 100%)'
        },
        {
          tag: '限时免费',
          title: '东南亚市场洞察报告',
          desc: '覆盖6国 · 500+品牌数据 · 立即领取',
          gradient: 'linear-gradient(135deg, #1a1a2e 0%, #2d2d44 100%)'
        },
        {
          tag: '新品上线',
          title: 'CheetahGo 3.0 正式发布',
          desc: 'AI驱动的广告投放 · 效率提升300%',
          gradient: 'linear-gradient(135deg, #2563eb 0%, #60a5fa 100%)'
        }
      ],
      quickEntries: [
        { label: '报活动', icon: eventWhite, target: 'activityDetail', gradient: 'linear-gradient(135deg, #ff6b35, #ff8b5f)' },
        { label: '查报告', icon: reportWhite, target: 'reports', gradient: 'linear-gradient(135deg, #2563eb, #4f9dff)' },
        { label: '案例库', icon: caseWhite, target: 'cases', gradient: 'linear-gradient(135deg, #059669, #2dd4bf)' },
        { label: '资料库', icon: folderWhite, target: 'materials', gradient: 'linear-gradient(135deg, #7c3aed, #a78bfa)' },
        { label: '约咨询', icon: consultWhite, target: 'consult', gradient: 'linear-gradient(135deg, #d97706, #fbbf24)' }
      ],
      communities: [
        { title: '出海交流群', desc: '1,280人已加入', icon: gridOrange, bg: '#fff0ea' },
        { title: '买量优化群', desc: '856人已加入', icon: reportBlue, bg: '#ebf5ff' },
        { title: '电商出海群', desc: '1,032人已加入', icon: folderGreen, bg: '#ecfdf5' },
        { title: '游戏出海群', desc: '643人已加入', icon: casePurple, bg: '#f5f3ff' },
        { title: '合规交流群', desc: '421人已加入', icon: checkAmber, bg: '#fffbeb' }
      ],
      reports: [
        {
          title: '2026年Q2中国出海品牌Top50排行榜',
          date: '2026-06-15',
          source: '猎豹研究院',
          badge: '免费',
          gradient: 'linear-gradient(135deg, #1e3a5f, #2d5f8a)'
        },
        {
          title: '东南亚社交媒体营销白皮书 2026',
          date: '2026-06-10',
          source: 'CheetahGo',
          badge: '付费',
          gradient: 'linear-gradient(135deg, #2d1b4e, #5b3a8c)'
        },
        {
          title: '中东市场游戏出海深度报告',
          date: '2026-06-08',
          source: '出海情报站',
          badge: '免费',
          gradient: 'linear-gradient(135deg, #1a3c34, #2d6b5a)'
        },
        {
          title: '拉美电商市场机遇与挑战全景分析',
          date: '2026-05-28',
          source: '猎豹研究院',
          badge: '付费',
          gradient: 'linear-gradient(135deg, #4a1942, #8b4578)'
        }
      ],
      activityTabs: [
        { key: 'live', label: '直播' },
        { key: 'closed', label: '闭门会' },
        { key: 'salon', label: '线下沙龙' },
        { key: 'camp', label: '专题训练营' }
      ],
      activities: [
        {
          type: 'live',
          title: '出海直播季·第12期：TikTok Shop 新加坡爆单秘籍',
          time: '6月28日 20:00',
          location: '线上直播',
          count: '已报 186',
          icon: 'LIVE',
          gradient: 'linear-gradient(135deg, #ff6b35, #ff9a5c)'
        },
        {
          type: 'live',
          title: 'AI 时代的买量投放策略：从手动到智能',
          time: '7月5日 19:30',
          location: '线上直播',
          count: '已报 92',
          icon: 'AI',
          gradient: 'linear-gradient(135deg, #2563eb, #60a5fa)'
        },
        {
          type: 'live',
          title: '出海实战：独立站从0到100万美元的完整路径',
          time: '7月12日 20:00',
          location: '线上直播',
          count: '已报 245',
          icon: 'SHOP',
          full: true,
          gradient: 'linear-gradient(135deg, #10b981, #34d399)'
        },
        {
          type: 'closed',
          title: '中东品牌增长闭门会：支付、合规与渠道打法',
          time: '7月18日 14:00',
          location: '深圳南山',
          count: '已报 38',
          icon: 'VIP',
          gradient: 'linear-gradient(135deg, #1a1a2e, #3f3f5a)'
        },
        {
          type: 'salon',
          title: '独立站运营沙龙：从素材测试到转化漏斗优化',
          time: '7月24日 15:00',
          location: '上海静安',
          count: '已报 64',
          icon: '沙龙',
          gradient: 'linear-gradient(135deg, #f59e0b, #fbbf24)'
        },
        {
          type: 'camp',
          title: '跨境广告投放7天训练营',
          time: '8月1日开营',
          location: '线上训练营',
          count: '已报 112',
          icon: '营',
          gradient: 'linear-gradient(135deg, #8b5cf6, #a78bfa)'
        }
      ],
      serviceGroups: [
        {
          title: '核心服务',
          items: [
            { title: '查报告', desc: '海量行业报告、市场洞察一键查阅', icon: reportWhite, target: 'reports', gradient: 'linear-gradient(135deg, #2563eb, #4f9dff)' },
            { title: '案例库', desc: '精选出海成功案例，学习最佳实践', icon: caseWhite, target: 'cases', gradient: 'linear-gradient(135deg, #059669, #2dd4bf)' },
            { title: '资料库', desc: '产品操作手册、媒体指南、行业资料', icon: folderWhite, target: 'materials', gradient: 'linear-gradient(135deg, #7c3aed, #a78bfa)' },
            { title: '约咨询', desc: '1对1专家咨询，解决出海核心问题', icon: consultWhite, target: 'consult', gradient: 'linear-gradient(135deg, #d97706, #fbbf24)' }
          ]
        },
        {
          title: '效率工具',
          items: [
            { title: '市场诊断', desc: '快速评估目标市场的机会与风险', icon: searchWhite, gradient: 'linear-gradient(135deg, #dc2626, #fb7185)' },
            { title: '合规自查', desc: '数据隐私、广告政策一键检测', icon: checkWhite, gradient: 'linear-gradient(135deg, #0891b2, #22d3ee)' },
            { title: '素材灵感库', desc: '高转化广告素材参考与创意灵感', icon: eventWhite, gradient: 'linear-gradient(135deg, #db2777, #f472b6)' }
          ]
        }
      ],
      profileMenus: [
        { label: '我的报名', icon: calendarOrange },
        { label: '我的资料', icon: folderOrange },
        { label: '我的收藏', icon: checkOrange },
        { label: '约咨询记录', icon: consultOrange }
      ],
      reportFilters: [
        { key: 'region', label: '全部地区' },
        { key: 'industry', label: '全部行业' },
        { key: 'year', label: '2026' }
      ],
      caseFilters: [
        { key: 'industry', label: '全部行业' },
        { key: 'service', label: '全部服务' }
      ],
      cases: [
        {
          title: '某美妆品牌：TikTok 投放ROI从1.2提升至4.8',
          industry: '美妆个护',
          service: '买量投放',
          icon: '店',
          metrics: ['ROI +300%', '日消耗 50K+'],
          gradient: 'linear-gradient(135deg, #10b981, #34d399)'
        },
        {
          title: '某游戏公司：日本市场CPI降低60%，D7留存提升35%',
          industry: '游戏',
          service: '整合营销',
          icon: '游',
          metrics: ['CPI -60%', '留存 +35%'],
          gradient: 'linear-gradient(135deg, #2563eb, #60a5fa)'
        },
        {
          title: '某3C品牌：独立站月销从8万到80万美元',
          industry: '3C数码',
          service: '独立站运营',
          icon: '3C',
          metrics: ['GMV +900%', '3个月达成'],
          gradient: 'linear-gradient(135deg, #f59e0b, #fbbf24)'
        }
      ],
      materialTabs: [
        { key: 'media', label: '媒体指南' },
        { key: 'lobster', label: '龙虾操作手册' },
        { key: 'fastgrow', label: 'FastGrow手册' }
      ],
      materials: {
        media: [
          { title: '2026年海外媒体投放渠道指南', size: 'PDF · 2.3MB', date: '2026-06', gradient: 'linear-gradient(135deg, #8b5cf6, #a78bfa)' },
          { title: 'Google Ads 最佳实践手册 2026', size: 'PDF · 4.1MB', date: '2026-05', gradient: 'linear-gradient(135deg, #6366f1, #818cf8)' },
          { title: 'Meta 广告政策合规速查手册', size: 'PDF · 1.8MB', date: '2026-05', gradient: 'linear-gradient(135deg, #7c3aed, #a78bfa)' }
        ],
        lobster: [
          { title: '龙虾投放平台入门指南', size: 'PDF · 3.2MB', date: '2026-04', gradient: 'linear-gradient(135deg, #ef4444, #f87171)' },
          { title: '龙虾自动化规则配置手册', size: 'PDF · 2.6MB', date: '2026-04', gradient: 'linear-gradient(135deg, #f97316, #fb923c)' }
        ],
        fastgrow: [
          { title: 'FastGrow 素材测试工作流', size: 'PDF · 2.9MB', date: '2026-06', gradient: 'linear-gradient(135deg, #06b6d4, #22d3ee)' },
          { title: 'FastGrow 数据看板使用手册', size: 'PDF · 3.7MB', date: '2026-05', gradient: 'linear-gradient(135deg, #0f766e, #14b8a6)' }
        ]
      },
      consultHighlights: ['资深专家', '30分钟深度', '保密承诺'],
      consultTopics: ['市场进入策略', '广告投放优化', '产品本地化', '合规与政策', '其他'],
      industries: ['电商', '游戏', '社交', '工具', '教育', '其他'],
      budgets: ['5万以下', '5-20万', '20-50万', '50-100万', '100万以上'],
      posters: [
        {
          title: '出海增长峰会 2026',
          desc: '7月15日 · 深圳南山\n20位行业大咖 · 限额200人',
          action: '立即报名',
          gradient: 'linear-gradient(135deg, #ff6b35, #ff9a5c)'
        },
        {
          title: '猎豹出海工具箱',
          desc: '活动报名 · 行业报告 · 案例库\n一站式出海服务平台',
          action: '探索更多',
          gradient: 'linear-gradient(135deg, #1a1a2e, #2d2d44)'
        },
        {
          title: '限时免费',
          desc: '东南亚市场洞察报告\n500+品牌数据 · 立即领取',
          action: '免费领取',
          gradient: 'linear-gradient(135deg, #10b981, #059669)'
        }
      ]
    }
  },
  computed: {
    featuredReports() {
      return this.reports.slice(0, 3)
    },
    visibleActivities() {
      return this.activities.filter((item) => item.type === this.activeActivityTab)
    },
    materialFiles() {
      return this.materials[this.activeMaterialTab] || []
    },
    subTitle() {
      const titleMap = {
        activityDetail: '活动详情',
        reports: '行业报告',
        reportDetail: '报告详情',
        cases: '案例库',
        materials: '资料库',
        consult: '约咨询'
      }
      return titleMap[this.activeSub] || ''
    }
  },
  mounted() {
    this.posterOpenTimer = setTimeout(() => {
      this.activeModal = 'posterModal'
    }, 500)
  },
  beforeUnmount() {
    if (this.posterOpenTimer) {
      clearTimeout(this.posterOpenTimer)
    }
  },
  methods: {
    switchTab(tab) {
      this.activeTab = tab
      this.activeSub = ''
    },
    openSub(name) {
      const routeMap = {
        activityDetail: '/pages/activity/detail',
        reports: '/pages/report/list',
        reportDetail: '/pages/report/detail',
        cases: '/pages/case/list',
        materials: '/pages/material/list',
        consult: '/pages/consult/index'
      }
      const path = routeMap[name]
      if (path) {
        uni.navigateTo({ url: path })
      }
    },
    closeSub() {
      this.activeSub = ''
    },
    showModal(id) {
      this.activeModal = id
    },
    hideModal(id) {
      if (!id || this.activeModal === id) {
        this.activeModal = ''
      }
    },
    handleBannerChange(event) {
      this.bannerIndex = event.detail.current
    },
    handlePosterChange(event) {
      this.posterIndex = event.detail.current
    },
    setMaterialTab(key) {
      this.activeMaterialTab = key
    },
    toggleFilter(group, key) {
      const filters = this.activeFilters[group]
      const index = filters.indexOf(key)
      if (index > -1) {
        filters.splice(index, 1)
      } else {
        filters.push(key)
      }
    },
    handlePicker(field, options, event) {
      const index = Number(event.detail.value)
      this[field] = options[index] || ''
    },
    signActivity(item) {
      if (item.full) {
        this.toast('该活动已满额')
        return
      }
      this.showModal('infoModal')
    },
    fromLoginToInfo() {
      uni.login({
        provider: 'weixin',
        success: (res) => {
          console.log('login code:', res.code)
          // TODO: 调后端接口换取 openid
          this.activeModal = 'infoModal'
        },
        fail: () => {
          uni.showToast({ title: '登录失败，请重试', icon: 'none' })
        }
      })
    },
    fromInfoToDeep() {
      this.activeModal = 'deepFormModal'
    },
    submitDeepForm() {
      this.activeModal = 'successModal'
    },
    toast(title) {
      uni.showToast({
        title,
        icon: 'none'
      })
    }
  }
}
</script>

<style scoped>
.toolbox-page {
  position: relative;
  width: 100%;
  min-height: 100%;
  background: #f6f7fb;
  overflow-x: hidden;
}

.top-header,
.bottom-tabs,
.sub-page,
.detail-cta-bar,
.modal-overlay {
  left: 0;
  right: 0;
  width: 100%;
}

/* #ifdef H5 */
.toolbox-page {
  width: min(100vw, 430px);
  max-width: 430px;
  min-height: 100vh;
  margin: 0 auto;
  box-shadow: 0 0 0 0.5px rgba(15, 23, 42, 0.08);
}

.top-header,
.bottom-tabs,
.sub-page,
.detail-cta-bar,
.modal-overlay {
  width: min(100vw, 430px);
  left: 50%;
  right: auto;
  transform: translateX(-50%);
}
/* #endif */

.icon-image {
  display: block;
}

button {
  margin: 0;
  padding: 0;
  border: 0;
  box-sizing: border-box;
  line-height: 1;
}

button::after {
  border: 0;
}

.top-header {
  position: fixed;
  z-index: 50;
  top: 0;
  height: 54px;
  padding: 12px 16px 8px;
  background: rgba(255, 255, 255, 0.94);
  border-bottom: 0.5px solid rgba(229, 231, 235, 0.7);
  display: flex;
  align-items: center;
  justify-content: flex-start;
}

/* #ifdef H5 */
.top-header {
  backdrop-filter: blur(9px);
}
/* #endif */

.brand {
  display: flex;
  align-items: center;
  gap: 8px;
  max-width: calc(100% - 52px);
}

.logo-mark,
.login-logo {
  width: 29px;
  height: 29px;
  border-radius: 8px;
  background: transparent;
  display: flex;
  align-items: center;
  justify-content: center;
}

.logo-image {
  width: 100%;
  height: 100%;
}

.brand-name {
  font-size: 15.5px;
  font-weight: 800;
  color: #1a1a2e;
  letter-spacing: 0;
}

.header-action {
  position: absolute;
  top: 9px;
  right: 16px;
  width: 36px;
  height: 36px;
  margin: 0 !important;
  padding: 0 !important;
  border-radius: 9px;
  background: #f3f4f6;
  display: flex;
  align-items: center;
  justify-content: center;
  flex: 0 0 36px;
}

.header-action-icon {
  width: 20px;
  height: 20px;
  color: #6b7280;
  flex: 0 0 20px;
}

.main-scroll {
  min-height: 100%;
  padding-top: 54px;
  padding-bottom: 76px;
  overflow: visible;
}

/* #ifdef H5 */
.main-scroll {
  min-height: 100vh;
  padding-bottom: calc(76px + env(safe-area-inset-bottom));
}
/* #endif */

.page-panel {
  min-height: 100%;
}

.carousel-wrap {
  padding: 12px 14px 4px;
}

.banner-swiper {
  height: 152px;
}

.carousel-card {
  height: 152px;
  border-radius: 8px;
  padding: 21px;
  display: flex;
  align-items: center;
  overflow: hidden;
  box-shadow: 0 8px 21px rgba(255, 107, 53, 0.18);
}

.banner-tag {
  align-self: flex-start;
  display: inline-flex;
  padding: 3px 10px;
  border-radius: 499.5px;
  background: rgba(255, 255, 255, 0.25);
  color: #ffffff;
  font-size: 11px;
  font-weight: 500;
  margin-bottom: 8px;
}

.banner-title {
  display: block;
  font-size: 21px;
  line-height: 26px;
  font-weight: 800;
  color: #ffffff;
}

.banner-desc {
  display: block;
  margin-top: 4px;
  font-size: 13px;
  line-height: 18px;
  color: rgba(255, 255, 255, 0.86);
}

.carousel-dots,
.poster-dots {
  display: flex;
  justify-content: center;
  gap: 6px;
  padding-top: 9px;
}

.dot {
  width: 6px;
  height: 6px;
  border-radius: 3px;
  background: #e5e7eb;
  transition: width 0.25s ease, background 0.25s ease;
}

.dot.active {
  width: 18px;
  background: #ff6b35;
}

.section {
  padding: 0 14px;
  margin-bottom: 20px;
}

.last-section {
  padding-bottom: 16px;
}

.section-title-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
}

.section-title {
  font-size: 17px;
  line-height: 22px;
  font-weight: 700;
  color: #1a1a2e;
}

.section-more {
  font-size: 12px;
  color: #9ca3af;
}

.entry-grid {
  display: flex;
  justify-content: space-between;
}

.entry-item {
  width: 20%;
  display: flex;
  align-items: center;
  flex-direction: column;
  gap: 6px;
}

.entry-icon {
  width: 46px;
  height: 46px;
  border-radius: 9px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 6px 12px rgba(15, 23, 42, 0.12);
}

.entry-glyph {
  width: 21px;
  height: 21px;
  color: #ffffff;
}

.entry-label {
  font-size: 11.5px;
  color: #4b5563;
  font-weight: 600;
}

.community-scroll {
  width: 100%;
  white-space: nowrap;
}

.community-card {
  width: 138px;
  min-height: 83px;
  display: inline-flex;
  flex-direction: column;
  justify-content: center;
  margin-right: 9px;
  padding: 13px;
  background: #ffffff;
  border-radius: 8px;
  border: 0.5px solid rgba(229, 231, 235, 0.9);
  box-shadow: 0 4px 12px rgba(15, 23, 42, 0.05);
}

.cc-icon {
  width: 34px;
  height: 34px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 13px;
  font-weight: 800;
  margin-bottom: 8px;
}

.cc-glyph {
  width: 17px;
  height: 17px;
}

.card-title {
  font-size: 13px;
  line-height: 18px;
  font-weight: 600;
  color: #1a1a2e;
}

.card-desc {
  font-size: 11px;
  line-height: 16px;
  color: #9ca3af;
}

.report-card,
.activity-card {
  margin-bottom: 10px;
  border-radius: 8px;
  background: #ffffff;
  overflow: hidden;
  border: 0.5px solid rgba(229, 231, 235, 0.9);
  box-shadow: 0 4px 13px rgba(15, 23, 42, 0.05);
}

.report-cover {
  position: relative;
  height: 110px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.report-watermark,
.report-cover-text {
  color: rgba(255, 255, 255, 0.34);
  font-size: 14px;
  font-weight: 700;
}

.report-badge {
  position: absolute;
  top: 8px;
  right: 8px;
  padding: 2.5px 8px;
  border-radius: 4px;
  color: #ffffff;
  font-size: 10px;
  font-weight: 700;
}

.report-badge.free {
  background: #10b981;
}

.report-badge.vip {
  background: #ff6b35;
}

.report-body,
.activity-body {
  padding: 12px 13px 13px;
}

.report-title,
.activity-title {
  display: block;
  color: #1a1a2e;
  font-size: 14px;
  line-height: 20px;
  font-weight: 600;
}

.report-meta,
.activity-info {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 4px;
  color: #9ca3af;
  font-size: 11px;
  line-height: 16px;
}

.page-heading {
  height: 48px;
  padding: 0 14px;
  background: #f6f7fb;
  border-bottom: 0;
  display: flex;
  align-items: center;
  font-size: 17px;
  font-weight: 700;
}

.sub-tabs {
  width: 100%;
  white-space: nowrap;
  padding: 3px 14px 9px;
  background: #f6f7fb;
  border-bottom: 0;
}

.sub-tab {
  display: inline-flex;
  align-items: center;
  height: 29px;
  padding: 0 16px;
  margin-right: 6px;
  border-radius: 7px;
  background: #ffffff;
  color: #64748b;
  font-size: 13px;
  font-weight: 600;
  border: 0.5px solid rgba(229, 231, 235, 0.9);
}

.sub-tab.active {
  background: #ff6b35;
  color: #ffffff;
}

.search-bar {
  margin: 8px 14px 12px;
  height: 41px;
  padding: 0 12px;
  border-radius: 8px;
  background: #ffffff;
  border: 0.5px solid rgba(229, 231, 235, 0.9);
  box-shadow: 0 4px 11px rgba(15, 23, 42, 0.04);
  display: flex;
  align-items: center;
  gap: 8px;
}

.search-icon {
  width: 15px;
  height: 15px;
  color: #9ca3af;
}

.search-input {
  flex: 1;
  height: 40px;
  font-size: 14px;
  color: #1a1a2e;
}

.placeholder,
.muted {
  color: #9ca3af;
}

.activity-cover {
  height: 126px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.activity-glyph {
  font-size: 23px;
  font-weight: 800;
  color: #ffffff;
  letter-spacing: 0;
}

.mini-primary {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 80px;
  height: 30px;
  margin-top: 10px;
  padding: 0 18px;
  border-radius: 499.5px;
  background: #ff6b35;
  color: #ffffff;
  font-size: 13px;
  font-weight: 700;
}

.mini-primary.outline {
  background: transparent;
  border: 1.5px solid #ff6b35;
  color: #ff6b35;
}

.service-group {
  padding: 10px 0 4px;
}

.service-group-title {
  display: block;
  padding: 0 14px 9px;
  font-size: 12px;
  color: #64748b;
  font-weight: 700;
  letter-spacing: 1px;
}

.service-list {
  padding: 0 14px;
}

.service-item,
.menu-item,
.community-join {
  display: flex;
  align-items: center;
  gap: 12px;
  background: #ffffff;
}

.service-item {
  min-height: 72px;
  margin-bottom: 8px;
  padding: 13px 14px;
  border-radius: 8px;
  border: 0.5px solid rgba(229, 231, 235, 0.9);
  box-shadow: 0 4px 13px rgba(15, 23, 42, 0.05);
}

.service-icon {
  flex: 0 0 auto;
  width: 42px;
  height: 42px;
  border-radius: 8px;
  color: #ffffff;
  display: flex;
  align-items: center;
  justify-content: center;
}

.service-glyph {
  width: 19px;
  height: 19px;
}

.service-copy {
  flex: 1;
  min-width: 0;
}

.service-title {
  display: block;
  color: #1a1a2e;
  font-size: 15px;
  line-height: 20px;
  font-weight: 700;
}

.service-desc {
  display: block;
  margin-top: 2px;
  color: #9ca3af;
  font-size: 12px;
  line-height: 17px;
}

.chevron {
  color: #9ca3af;
  font-size: 20px;
  line-height: 1;
}

.profile-card {
  min-height: 92px;
  margin: 10px 14px 0;
  padding: 19px 17px;
  border-radius: 8px;
  background: linear-gradient(135deg, #1f2937, #ff6b35);
  color: #ffffff;
  display: flex;
  align-items: center;
  gap: 14px;
}

.profile-avatar {
  width: 56px;
  height: 56px;
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.25);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 21px;
  font-weight: 800;
}

.profile-name {
  display: block;
  font-size: 18px;
  line-height: 23px;
  font-weight: 800;
}

.profile-desc {
  display: block;
  margin-top: 2px;
  font-size: 12px;
  color: rgba(255, 255, 255, 0.82);
}

.menu-list {
  margin: 10px 14px;
  border-radius: 8px;
  background: #ffffff;
  overflow: hidden;
  border: 0.5px solid rgba(229, 231, 235, 0.9);
  box-shadow: 0 4px 13px rgba(15, 23, 42, 0.05);
}

.menu-item {
  min-height: 48px;
  padding: 12px 14px;
  border-bottom: 0.5px solid #e5e7eb;
}

.menu-item:last-child {
  border-bottom: 0;
}

.menu-icon {
  width: 18px;
  height: 18px;
  color: #ff6b35;
}

.menu-icon.wechat {
  color: #07c160;
}

.menu-icon.muted {
  color: #9ca3af;
}

.menu-text {
  flex: 1;
  color: #1a1a2e;
  font-size: 15px;
}

.bottom-tabs {
  position: fixed;
  z-index: 55;
  bottom: 0;
  height: 59px;
  padding: 7px 9px 0;
  background: rgba(255, 255, 255, 0.96);
  border-top: 0.5px solid rgba(229, 231, 235, 0.85);
  display: flex;
}

/* #ifdef H5 */
.bottom-tabs {
  height: calc(59px + env(safe-area-inset-bottom));
  padding: 7px 9px env(safe-area-inset-bottom);
  backdrop-filter: blur(9px);
}
/* #endif */

.bottom-tab {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 2px;
  color: #9ca3af;
  font-size: 10px;
  border-radius: 8px;
}

.bottom-tab.active {
  color: #ff6b35;
  background: #fff0ea;
}

.bottom-icon {
  width: 19px;
  height: 19px;
}

.bottom-label {
  font-size: 10px;
  line-height: 14px;
}

.sub-page {
  position: fixed;
  z-index: 90;
  top: 0;
  bottom: 0;
  background: #f6f7fb;
}

.back-header {
  position: relative;
  height: 54px;
  padding: 12px 14px 8px;
  border-bottom: 0.5px solid rgba(229, 231, 235, 0.75);
  display: flex;
  align-items: center;
  gap: 10px;
  background: rgba(255, 255, 255, 0.96);
}

/* #ifdef H5 */
.back-header {
  backdrop-filter: blur(9px);
}
/* #endif */

.back-button {
  position: absolute;
  z-index: 2;
  left: 14px;
  top: 14px;
  width: 26px;
  height: 26px;
  margin: 0;
  padding: 0;
  border-radius: 8px;
  background: #f8fafc;
  color: #1a1a2e;
  font-size: 28px;
  line-height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.back-title {
  position: absolute;
  left: 50%;
  max-width: 68%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  transform: translateX(-50%);
  font-size: 16px;
  font-weight: 700;
  color: #1a1a2e;
}

.sub-scroll {
  height: calc(100% - 54px);
  background: #f6f7fb;
}

.sub-scroll.with-cta {
  height: calc(100% - 112px);
}

/* #ifdef H5 */
.sub-scroll {
  height: calc(100vh - 54px);
}

.sub-scroll.with-cta {
  height: calc(100vh - 112px - env(safe-area-inset-bottom));
}
/* #endif */

.detail-cover {
  height: 200px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.detail-cover-center {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  color: #ffffff;
}

.detail-cover-icon {
  font-size: 28px;
  line-height: 31px;
  font-weight: 800;
}

.detail-cover-title {
  font-size: 18px;
  font-weight: 800;
}

.detail-info-block,
.detail-content {
  background: #ffffff;
  padding: 16px 14px;
}

.detail-content {
  margin: 10px 14px;
  border-radius: 8px;
  border: 0.5px solid rgba(229, 231, 235, 0.9);
}

.detail-title {
  display: block;
  color: #1a1a2e;
  font-size: 20px;
  line-height: 26px;
  font-weight: 800;
}

.detail-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 12px;
}

.detail-tag {
  padding: 4px 10px;
  border-radius: 5px;
  background: #f6f7fb;
  color: #64748b;
  font-size: 12px;
  line-height: 17px;
}

.detail-content-title {
  display: block;
  margin-bottom: 9px;
  color: #1a1a2e;
  font-size: 16px;
  line-height: 21px;
  font-weight: 800;
}

.detail-p {
  display: block;
  margin-bottom: 10px;
  color: #6b7280;
  font-size: 14px;
  line-height: 24px;
}

.filter-bar {
  width: 100%;
  padding: 8px 14px;
  white-space: nowrap;
  background: #f6f7fb;
}

.filter-btn {
  display: inline-flex;
  align-items: center;
  height: 29px;
  padding: 0 14px;
  margin-right: 8px;
  border: 0.5px solid rgba(229, 231, 235, 0.95);
  border-radius: 7px;
  color: #64748b;
  background: #ffffff;
  font-size: 12px;
}

.filter-btn.active {
  color: #ff6b35;
  border-color: rgba(255, 107, 53, 0.35);
  background: #fff0ea;
}

.top-gap {
  margin-top: 12px;
}

.metric-row {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 9px;
}

.metric-badge {
  padding: 4px 10px;
  border-radius: 5px;
  background: #fff0ea;
  color: #ff6b35;
  font-size: 11px;
  font-weight: 700;
}

.material-tabs {
  display: flex;
  height: 48px;
  background: #ffffff;
  border-bottom: 0.5px solid rgba(229, 231, 235, 0.9);
}

.material-tab {
  flex: 1;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #6b7280;
  font-size: 14px;
  font-weight: 500;
}

.material-tab.active {
  color: #ff6b35;
  font-weight: 700;
}

.material-tab.active::after {
  content: "";
  position: absolute;
  left: 50%;
  bottom: 0;
  width: 24px;
  height: 3px;
  border-radius: 3px;
  background: #ff6b35;
  transform: translateX(-50%);
}

.material-cover {
  height: 80px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: rgba(255, 255, 255, 0.5);
  font-size: 14px;
  font-weight: 800;
}

.consult-hero {
  margin: 12px 14px 0;
  padding: 26px 21px;
  border-radius: 8px;
  background: linear-gradient(135deg, #1f2937, #ff6b35);
  color: #ffffff;
  text-align: center;
}

.consult-title {
  display: block;
  font-size: 24px;
  line-height: 29px;
  font-weight: 800;
}

.consult-desc {
  display: block;
  margin-top: 6px;
  font-size: 14px;
  line-height: 20px;
  color: rgba(255, 255, 255, 0.9);
}

.consult-highlights {
  padding: 16px 14px;
  display: flex;
  justify-content: space-between;
}

.consult-hl-item {
  flex: 1;
  min-height: 72px;
  border-radius: 8px;
  background: #ffffff;
  border: 0.5px solid rgba(229, 231, 235, 0.9);
  box-shadow: 0 4px 13px rgba(15, 23, 42, 0.05);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 6px;
  color: #1a1a2e;
  font-size: 12px;
  font-weight: 700;
}

.consult-hl-item + .consult-hl-item {
  margin-left: 10px;
}

.consult-hl-icon {
  width: 19px;
  height: 19px;
  color: #ff6b35;
}

.form-section {
  padding: 0 14px 20px;
}

.form-title {
  display: block;
  margin-bottom: 14px;
  color: #1a1a2e;
  font-size: 16px;
  line-height: 21px;
  font-weight: 800;
}

.form-group {
  margin-bottom: 14px;
}

.form-label {
  display: block;
  margin-bottom: 6px;
  color: #6b7280;
  font-size: 13px;
  font-weight: 700;
}

.form-input {
  width: 100%;
  min-height: 44px;
  padding: 0 14px;
  border: 0.5px solid rgba(203, 213, 225, 0.95);
  border-radius: 8px;
  background: #ffffff;
  color: #1a1a2e;
  font-size: 14px;
}

.select-input {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.form-textarea {
  height: 80px;
  padding-top: 10px;
  line-height: 20px;
}

.btn-primary {
  width: 100%;
  height: 48px;
  border-radius: 8px;
  background: #ff6b35;
  color: #ffffff;
  font-size: 16px;
  font-weight: 800;
  display: flex;
  align-items: center;
  justify-content: center;
}

.community-join {
  margin: 14px;
  padding: 14px;
  border-radius: 8px;
  border: 0.5px solid rgba(229, 231, 235, 0.9);
  box-shadow: 0 4px 13px rgba(15, 23, 42, 0.05);
}

.join-icon {
  width: 44px;
  height: 44px;
  border-radius: 8px;
  background: #fff0ea;
  color: #ff6b35;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 800;
}

.join-copy {
  flex: 1;
}

.join-title {
  display: block;
  color: #1a1a2e;
  font-size: 14px;
  font-weight: 700;
}

.join-desc {
  display: block;
  margin-top: 2px;
  color: #9ca3af;
  font-size: 12px;
}

.detail-cta-bar {
  position: fixed;
  z-index: 95;
  bottom: 0;
  min-height: 58px;
  padding: 10px 14px;
  background: rgba(255, 255, 255, 0.96);
  border-top: 0.5px solid rgba(229, 231, 235, 0.85);
  display: flex;
  gap: 10px;
}

/* #ifdef H5 */
.detail-cta-bar {
  min-height: calc(58px + env(safe-area-inset-bottom));
  padding: 10px 14px calc(10px + env(safe-area-inset-bottom));
  backdrop-filter: blur(9px);
}
/* #endif */

.btn-cta {
  height: 44px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  font-weight: 800;
}

.btn-cta.primary {
  flex: 1;
  background: #ff6b35;
  color: #ffffff;
}

.btn-cta.soft {
  width: 110px;
  background: #fff0ea;
  color: #ff6b35;
  gap: 5px;
}

.cta-icon {
  width: 15px;
  height: 15px;
}

.cta-icon.light {
  color: #ffffff;
}

.modal-overlay {
  position: fixed;
  z-index: 120;
  top: 0;
  bottom: 0;
  padding: 40px 22px;
  background: rgba(15, 23, 42, 0.56);
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal {
  position: relative;
  width: 100%;
  max-height: 88%;
  border-radius: 9px;
  background: #ffffff;
  overflow: hidden;
  box-shadow: 0 14px 36px rgba(15, 23, 42, 0.26);
}

/* #ifdef H5 */
.modal {
  max-height: 88vh;
}
/* #endif */

.login-modal {
  padding: 36px 22px 26px;
  text-align: center;
  display: flex;
  align-items: center;
  flex-direction: column;
}

.modal-close,
.poster-close {
  position: absolute;
  z-index: 2;
  top: 12px;
  right: 12px;
  width: 28px;
  height: 28px;
  border-radius: 7px;
  background: rgba(15, 23, 42, 0.22);
  color: #ffffff;
  font-size: 17px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal-close.orange {
  background: #ff6b35;
}

.login-logo {
  width: 40px;
  height: 40px;
  margin-bottom: 20px;
}

.modal-title {
  display: block;
  color: #1a1a2e;
  font-size: 20px;
  line-height: 25px;
  font-weight: 800;
  text-align: center;
}

.modal-title.left {
  text-align: left;
  padding: 24px 22px 0;
}

.modal-desc {
  display: block;
  margin-top: 8px;
  color: #9ca3af;
  font-size: 13px;
  line-height: 19px;
  text-align: center;
}

.modal-desc.left {
  text-align: left;
  padding: 0 22px;
  margin-bottom: 16px;
}

.permission-list {
  width: 100%;
  margin: 20px 0;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.permission-item {
  color: #6b7280;
  font-size: 13px;
  line-height: 18px;
  text-align: left;
}

.wx-btn {
  width: 100%;
  height: 48px;
  border-radius: 8px;
  background: #07c160;
  color: #ffffff;
  font-size: 16px;
  font-weight: 800;
  display: flex;
  align-items: center;
  justify-content: center;
}

.form-modal {
  padding-bottom: 24px;
}

.modal-field {
  padding: 0 22px;
}

.modal-submit {
  width: calc(100% - 44px);
  margin: 4px 22px 0;
}

.success-modal {
  padding: 40px 24px 24px;
  text-align: center;
  display: flex;
  align-items: center;
  flex-direction: column;
}

.success-icon {
  width: 64px;
  height: 64px;
  border-radius: 8px;
  background: #fff0ea;
  color: #ff6b35;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 32px;
  font-weight: 800;
  margin-bottom: 16px;
}

.success-title {
  color: #1a1a2e;
  font-size: 20px;
  font-weight: 800;
}

.success-desc {
  margin: 8px 0 24px;
  color: #9ca3af;
  font-size: 14px;
  line-height: 20px;
}

.poster-modal {
  overflow: hidden;
}

.poster-swiper {
  height: 270px;
}

.poster-slide {
  height: 270px;
  padding: 27px;
  color: #ffffff;
  display: flex;
  align-items: flex-start;
  justify-content: flex-end;
  flex-direction: column;
  text-align: left;
}

.poster-title {
  font-size: 23px;
  line-height: 29px;
  font-weight: 800;
}

.poster-desc {
  margin-top: 9px;
  color: rgba(255, 255, 255, 0.88);
  font-size: 13px;
  line-height: 21px;
  white-space: pre-line;
}

.poster-cta {
  min-width: 110px;
  height: 40px;
  margin-top: 17px;
  padding: 0 21px;
  border-radius: 8px;
  background: #ffffff;
  color: #ff6b35;
  font-size: 14px;
  font-weight: 800;
  display: flex;
  align-items: center;
  justify-content: center;
}

.poster-dots {
  padding: 10px 0;
  background: #ffffff;
}
</style>
