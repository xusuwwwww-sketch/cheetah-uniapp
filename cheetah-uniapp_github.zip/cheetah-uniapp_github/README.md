# 猎豹出海工具箱 Uniapp 版

这是从 `/Users/cm/Downloads/cheetah-toolbox-demo.html` 重构出来的 Uniapp/Vue3 项目。

## 运行

1. 在 HBuilderX 中导入 `outputs/cheetah-uniapp`，选择 H5 或微信小程序运行。
2. 或使用命令行：

```bash
npm install
npm run dev:h5
```

## 已迁移内容

- 首页 banner、快捷入口、热门社群、精选报告
- 活动、服务、我的四个主 tab
- 活动详情、报告列表、报告详情、案例库、资料库、约咨询等子页面
- 登录、完善信息、深度调研、提交成功、启动海报弹窗
- 原始 DOM 操作已改为 Uniapp 状态驱动和列表渲染
